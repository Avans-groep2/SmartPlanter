<template>
  <div id="layout">
    <NavBar/>
    <main class="content">
      <router-view/>
    </main>
  <FooterBar/>

    </div>
</template>

<script>
import FooterBar from './components/FooterBar.vue';
import NavBar from './components/NavBar.vue';



export default {
  name: 'App',
  components: {
    FooterBar, NavBar,
  },
  data() {
    return {
      username: '',
      token: ''
    }
  },
  mounted() {
    const keycloak = this.$keycloak;
    
    if (keycloak && keycloak.authenticated) {
      this.username = keycloak.tokenParsed.preferred_username || keycloak.tokenParsed.name || 'Gebruiker';
      this.token = keycloak.token;
    }
  },
  methods: {
    logout() {
      this.$keycloak.logout();
    }
  }
};


</script>

<style>

#app{
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

#layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.content {
  flex: 1;
}

* {
  margin: 0;
  padding: 0;
}

footer {
  margin-top: auto;
}

NavBar {
  margin-top: auto;
}

body {
  background-color: #e7e6dc;
}
</style>
